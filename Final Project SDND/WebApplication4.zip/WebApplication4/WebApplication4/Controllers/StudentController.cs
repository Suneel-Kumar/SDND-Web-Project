﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication4.Controllers
{
    public class StudentController : Controller
    {
        // GET: Student
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult elearn()
        {
            return View();
        }


        public ActionResult slide()
        {
            return View();
        }


        public ActionResult quiz()
        {

            return View();

        }
    }
}